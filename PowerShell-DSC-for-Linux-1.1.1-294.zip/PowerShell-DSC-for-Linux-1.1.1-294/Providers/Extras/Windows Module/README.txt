Please put the folder in this directory into:
	C:\Windows\System32\WindowsPowerShell\v1.0\Modules
	
This will allow the building of configuration MOF files from configuration files in powershell using our new definition MOFs for Linux.