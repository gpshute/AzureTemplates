#!/bin/bash
service --status-all


