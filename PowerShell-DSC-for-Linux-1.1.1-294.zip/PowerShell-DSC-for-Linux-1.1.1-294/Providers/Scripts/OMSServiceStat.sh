#!/bin/bash
service $1 status


