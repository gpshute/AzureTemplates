#!/bin/bash
zypper -qn refresh &> /dev/null
zypper -q lu 


