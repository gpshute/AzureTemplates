﻿if(Test-Path fileunitestdata)
{
    del fileunitestdata -Force -Recurse
}
